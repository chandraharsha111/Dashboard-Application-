﻿namespace CourseProjectApp.Services
{
    public class MessageSenderOptions
    {
        public string SendGridApiKey { get; set; }

        public string Sid { get; set; }

        public string AuthoToken { get; set; }
    }
}
